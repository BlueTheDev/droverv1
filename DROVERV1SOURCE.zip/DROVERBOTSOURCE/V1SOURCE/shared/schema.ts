import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tempBans = pgTable("temp_bans", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  guildId: text("guild_id").notNull(),
  duration: integer("duration").notNull(), // in minutes
  reason: text("reason"),
  expiresAt: integer("expires_at").notNull()
});

export const insertTempBanSchema = createInsertSchema(tempBans).omit({
  id: true
});

export type InsertTempBan = z.infer<typeof insertTempBanSchema>;
export type TempBan = typeof tempBans.$inferSelect;
